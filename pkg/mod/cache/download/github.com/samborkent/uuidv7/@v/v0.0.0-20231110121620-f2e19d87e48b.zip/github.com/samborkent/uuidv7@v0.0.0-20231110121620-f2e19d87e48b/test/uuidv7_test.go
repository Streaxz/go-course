package test

import (
	"fmt"
	"testing"

	"github.com/google/uuid"
	"github.com/samborkent/uuidv7"
)

const nRepeats = 3

func TestNewUUIDv7(t *testing.T) {
	id := uuidv7.New()
	fmt.Println("uuid: " + id.String())
	fmt.Println("creationTime: " + id.CreationTime().String())
	fmt.Printf("sequenceNumber: %d\n", id.SequenceNumber())
	fmt.Printf("is valid bytes: %t\n", uuidv7.IsValid(id[:]))

	if !uuidv7.IsValid(id[:]) {
		t.Error("invalid uuid bytes")
	}

	fmt.Printf("is valid string: %t\n", uuidv7.IsValidString(id.String()))

	if !uuidv7.IsValidString(id.String()) {
		t.Error("invalid uuid string")
	}

	fmt.Println()

	for i := 0; i < nRepeats; i++ {
		id := uuidv7.New()
		fmt.Printf("%d uuid: %s\n", i+1, id.String())
		fmt.Printf("%d creationTime: %s\n", i+1, id.CreationTime().String())
		fmt.Printf("%d sequenceNumber: %d\n", i+1, id.SequenceNumber())
		fmt.Println()
	}
}

func BenchmarkUUIDv4(b *testing.B) {
	for i := 0; i < b.N; i++ {
		_ = uuid.New()
	}
}

func BenchmarkUUIDv7(b *testing.B) {
	for i := 0; i < b.N; i++ {
		_ = uuidv7.New()
	}
}

func BenchmarkAfter(b *testing.B) {
	uuid1 := uuidv7.New()
	uuid2 := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid1.After(uuid2)
	}
}

func BenchmarkBefore(b *testing.B) {
	uuid1 := uuidv7.New()
	uuid2 := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid1.Before(uuid2)
	}
}

func BenchmarkCreationTime(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid.CreationTime()
	}
}

func BenchmarkSequenceNumber(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid.SequenceNumber()
	}
}

func BenchmarkShort(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid.Short()
	}
}

func BenchmarkStringV4(b *testing.B) {
	uuid := uuid.New()

	for i := 0; i < b.N; i++ {
		_ = uuid.String()
	}
}

func BenchmarkStringV7(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuid.String()
	}
}

func BenchmarkIsValid(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuidv7.IsValid(uuid[:])
	}
}

func BenchmarkIsValidString(b *testing.B) {
	uuid := uuidv7.New()

	for i := 0; i < b.N; i++ {
		_ = uuidv7.IsValidString(uuid.String())
	}
}
