/*
Go implementation of UUID v7 as defined in RFC4122. (https://datatracker.ietf.org/doc/html/draft-ietf-uuidrev-rfc4122bis)
UUID v7 unique identifiers are an improvement over UUID v1 and UUID v6.
They are lexicongraphically sortable by order of creation, while offering a high level of entropy.
*/
package uuidv7

import (
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"math"
	"sync"
	"time"
	"unicode"
	"unsafe"
)

type UUID [16]byte

var randPool = sync.Pool{
	New: func() any {
		randBuf := make([]byte, 8)
		return &randBuf
	},
}

// Generate a new UUID v7
func New() UUID {
	uuid := make([]byte, 16)

	ms, milliFrac := math.Modf(1e-6 * float64(time.Now().UnixNano()))

	msInt := uint64(ms)

	// Big endian binary encoding on Unix millisecond timestamp into the first 48 bits
	uuid[0] = byte(msInt >> 40)
	uuid[1] = byte(msInt >> 32)
	uuid[2] = byte(msInt >> 24)
	uuid[3] = byte(msInt >> 16)
	uuid[4] = byte(msInt >> 8)
	uuid[5] = byte(msInt)

	fracInt := uint16(4096 * milliFrac)

	// Big endian binary encoding of sequence number into bits 49 to 64
	uuid[6] = byte(fracInt >> 8)
	uuid[7] = byte(fracInt)

	// Sequence number only takes 12 bits, write version bits into bits 49 to 52
	uuid[6] = (uuid[6] & 0b01111111) | 0b01110000

	// Get buffer to store random bits from pool
	randBufPtr, _ := randPool.Get().(*[]byte)
	randBuf := *randBufPtr

	// Generate 64-bit pseudo-random number
	// Randomness is determined by crypto/rand package
	_, _ = rand.Read(randBuf)

	// Copy random bits to last 64 bits of UUID
	copy(uuid[8:], randBuf)

	// Return buffer to pool
	randPool.Put(randBufPtr)

	// Random bits should only takes 62 bits
	// Write variant bits into bits 65 and 66
	uuid[8] = (uuid[8] & 0b10111111) | 0b10000000

	return UUID(uuid)
}

// Check if a UUID was created after another UUID
func (uuid UUID) After(other UUID) bool {
	if uuid.CreationTime().Equal(other.CreationTime()) {
		return uuid.SequenceNumber() > other.SequenceNumber()
	}

	return uuid.CreationTime().After(other.CreationTime())
}

// Check if a UUID was created before another UUID
func (uuid UUID) Before(other UUID) bool {
	if uuid.CreationTime().Equal(other.CreationTime()) {
		return uuid.SequenceNumber() < other.SequenceNumber()
	}

	return uuid.CreationTime().Before(other.CreationTime())
}

// Get creation time of the UUID
// Only has an millisecond accuracy as defined by UUID v7 proposal
func (uuid UUID) CreationTime() time.Time {
	var creationTimeBits [8]byte

	copy(creationTimeBits[:], uuid[:8])

	// Right shift timestamp bytes
	rightShiftTimestamp(creationTimeBits[:])

	return time.UnixMilli(int64(binary.BigEndian.Uint64(creationTimeBits[:]))).UTC()
}

// Get sequence number of UUID
// Ihis can be used to sort UUIDs created within one millisecond
func (uuid UUID) SequenceNumber() int {
	var sequenceNumberBits [2]byte

	copy(sequenceNumberBits[:], uuid[6:8])

	// Remove version bits from sequence number
	sequenceNumberBits[0] = sequenceNumberBits[0] & 0b00001111

	return int(binary.BigEndian.Uint16(sequenceNumberBits[:]))
}

// Last 12 characters of UUID
// Useful for logging
func (uuid UUID) Short() string {
	buf := make([]byte, 12)

	hex.Encode(buf, uuid[10:])

	return *(*string)(unsafe.Pointer(&buf))
}

// Hyphen delimited string representation of UUID
// Can be used for a lexicographic sort, which will return UUID in order of creation
func (uuid UUID) String() string {
	buf := make([]byte, 36)

	encodeHex(buf, uuid)

	return *(*string)(unsafe.Pointer(&buf))
}

// Check if a byte slice is a valid UUID v7
func IsValid(uuid []byte) bool {
	// Check if correct number of bytes are present
	if len(uuid) != 16 {
		return false
	}

	versionByte := uuid[6]

	// Check version bits
	if versionByte|0b10001111 != 0b11111111 {
		return false
	}

	var timestampBytes [8]byte

	copy(timestampBytes[:], uuid[:8])

	// Right shift timestamp bytes
	rightShiftTimestamp(timestampBytes[:])

	// Reject UUIDs from the future
	if binary.BigEndian.Uint64(timestampBytes[:]) > uint64(time.Now().UnixMilli()) {
		return false
	}

	variantByte := uuid[8]

	// Check variant bits
	if variantByte|0b01111111 != 0b11111111 {
		return false
	}

	var randBytes [8]byte

	copy(randBytes[:], uuid[8:])

	randBytes[0] = randBytes[0] & 0b00111111

	// Check if random bits are filled
	return binary.BigEndian.Uint64(randBytes[:]) != 0
}

// Check if a string is a valid UUID v7
func IsValidString(uuid string) bool {
	newUUID := make([]byte, 0, 32)

	for i, r := range uuid {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			newUUID = append(newUUID, byte(r))
			continue
		}

		if r != '-' {
			return false
		}

		if i != 8 && i != 13 && i != 18 && i != 23 {
			return false
		}
	}

	// Check if string is the right length
	if len(newUUID) != 32 {
		return false
	}

	buf := make([]byte, 16)

	// Decode string
	_, err := hex.Decode(buf[:], newUUID)
	if err != nil {
		return false
	}

	return IsValid(buf[:])
}

// From github.com/google/uuid
func encodeHex(dst []byte, uuid [16]byte) {
	hex.Encode(dst, uuid[:4])
	dst[8] = '-'
	hex.Encode(dst[9:13], uuid[4:6])
	dst[13] = '-'
	hex.Encode(dst[14:18], uuid[6:8])
	dst[18] = '-'
	hex.Encode(dst[19:23], uuid[8:10])
	dst[23] = '-'
	hex.Encode(dst[24:], uuid[10:])
}

func rightShiftTimestamp(uuid []byte) {
	// Right shift timestamp bytes
	uuid[7] = uuid[5]
	uuid[6] = uuid[4]
	uuid[5] = uuid[3]
	uuid[4] = uuid[2]
	uuid[3] = uuid[1]
	uuid[2] = uuid[0]
	uuid[1] = 0
	uuid[0] = 0
}
